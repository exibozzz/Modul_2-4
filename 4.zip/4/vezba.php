<?php



$godine = 25;
 
if($godine >= 18) {echo "Vi ste punoletni.";}

else {echo "Vi ste maloletni.";}










?>
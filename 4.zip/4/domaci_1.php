<?php


$username = "adMIniSTraTOr";
$password = "mojaSifraJeSigurna";
$lower_username = strtolower($username); // bonus => kod za convert string to lowercase

echo "$lower_username";





if($lower_username == "administrator" && $password == "mojaSifraJeSigurna"){
    echo "Dobrodošao Administratore";
}







?>
<?php


$godina_rodjenja = 1996;
$trenutna_godina = date("Y");
$godine = $trenutna_godina-$godina_rodjenja;

$broj = 195;
$provera_broja = $broj % 2;

if($provera_broja == 0) {echo "Broj je paran";}

if($provera_broja == 1) {echo "Broj je neparan";}



$osobe = ["Milica", "Nikola", "Jovana", "Sandra", "Jovan", "Teodora"];

if (in_array("Teodoraa", $osobe)) {echo "Rezultat je pronadjen";}

else { echo "Rezultat nije pronadjen";}








?>
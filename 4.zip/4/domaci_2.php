<?php

$trenutno_vreme = date("H:i", strtotime("14:55"));



if($trenutno_vreme >= date("H:i", strtotime("05:00")) && $trenutno_vreme <= date("H:i", strtotime("11:59"))) {
    echo "Jutro jeee jutro jeeeeee kad te nema, bolje da se nisam ni probudila :D";
}

if($trenutno_vreme >= date("H:i", strtotime("12:00")) && $trenutno_vreme <= date("H:i", strtotime("19:59"))) {
    echo "Podne je.";
} 

if($trenutno_vreme >= date("H:i", strtotime("20:00"))) {
    echo "Noć je";
}

// Nadam se da je dobro, upada $trenutno_vreme u svaki if. 



?>